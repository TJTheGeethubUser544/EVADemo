extends CharacterBody3D

@onready var body: CharacterBody3D = $"."
var can_play_Warning1: bool
@export var eva_mouse_sens = 0.005
@export var angular_velocity: float = 0.0:
			set(value):
				angular_velocity = minf(value, 1.0)
@export var angular_acceleration : float = 20

#You will need to set your own escape key
func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _physics_process(delta: float) -> void:
	_EVASystem(delta)
	self.move_and_slide()

#EVA movement system
#You will also need to set your own movement keys
func _EVASystem(delta):
	var direction = Vector3.ZERO
	if not is_on_floor() or is_on_floor():
		if Input.is_action_pressed("forward"):
			velocity -= basis.z * 5 * delta
		if Input.is_action_pressed("backward"):
			velocity += basis.z * 5 * delta
		if Input.is_action_pressed("left"):
			velocity -= basis.x * 5 * delta
		if Input.is_action_pressed("right"):
			velocity += basis.x * 5 * delta
		if Input.is_action_pressed("up"):
			velocity += basis.y * 5 * delta
		if Input.is_action_pressed("down"):
			velocity -= basis.y * 5 * delta
		var roll := Input.get_axis("rollleft", "rollright")
		angular_velocity += deg_to_rad(angular_acceleration) * roll * delta
		rotate(-basis.z.normalized(), angular_velocity * delta)

		if Input.is_action_pressed("spacebreak"):
			velocity.x = lerp(velocity.x, 0.0, 2 * delta)
			velocity.y = lerp(velocity.y, 0.0, 2 * delta)
			velocity.z = lerp(velocity.z, 0.0, 2 * delta)
			angular_velocity -= (angular_velocity * 2) * delta

		if direction != Vector3.ZERO:
			global_transform.origin += direction.normalized() * 5 * delta

#Eva Camera system
		var mouse_delta = Input.get_last_mouse_velocity() * eva_mouse_sens * delta
		if mouse_delta != Vector2.ZERO:
			var updirection
			updirection = global_transform.basis.y.normalized()
			global_transform.basis = Basis(updirection, -mouse_delta.x) * global_transform.basis

			var rightdirection = global_transform.basis.x.normalized()
			global_transform.basis = Basis(rightdirection, -mouse_delta.y) * global_transform.basis
